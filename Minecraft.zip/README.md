
# CSS Minecraft

A Minecraft clone made with pure HTML & CSS – no JavaScript.

Play the game: [benjaminaster.com/css-minecraft](https://benjaminaster.com/css-minecraft/)

![screenshot of CSS Minecraft](./assets/screenshot.png)
